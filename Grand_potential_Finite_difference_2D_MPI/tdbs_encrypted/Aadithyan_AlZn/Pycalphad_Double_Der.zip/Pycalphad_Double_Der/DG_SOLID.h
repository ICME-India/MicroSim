/******************************************************************************
 *                       Code generated with sympy 1.8                        *
 *                                                                            *
 *              See http://www.sympy.org/ for more information.               *
 *                                                                            *
 *                       This file is part of 'project'                       *
 ******************************************************************************/


#ifndef PROJECT__DG_SOLID__H
#define PROJECT__DG_SOLID__H

void DG_SOLID(double T, double *y, double *dG);

#endif

