/******************************************************************************
 *                       Code generated with sympy 1.8                        *
 *                                                                            *
 *              See http://www.sympy.org/ for more information.               *
 *                                                                            *
 *                       This file is part of 'project'                       *
 ******************************************************************************/


#ifndef PROJECT__DG_LIQUID__H
#define PROJECT__DG_LIQUID__H

void DG_LIQUID(double T, double *y, double *dG);

#endif

